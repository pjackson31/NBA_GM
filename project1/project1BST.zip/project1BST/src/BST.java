import javax.swing.*;
import java.util.Random;
import java.io.IOException;

public class BST {
    BSTNode root;
    int size = 0;

    public BST() {
        root = null;
    }

    public int depth(BSTNode u) {
        int depth = 0;
        while (u != root) {
            u = u.parent;
            depth++;
        }
        return depth;
    }



    //useful for debugging and printing out the whole tree
    public void traversePrintIterative(BSTNode n) {
        BSTNode current = n;
        BSTNode prev = null;
        BSTNode next;
        while (current != null) {//continues going untill we react a
            if (prev == current.parent || prev == null) {
                System.out.println(current.giveName() + ""); //if we arrived here from the parent or a null(root case) then its a new node and we next visit the left
            }
            if (prev == current.parent) {
                if (current.left != null) next = current.left;
                else if (current.right != null) next = current.right;
                else next = current.parent;
            } else if (prev == current.left) {
                if (current.right != null) next = current.right;//also if the right node has a value
                else next = current.parent;//if the rigth node is null go up back to parent
            } else {
                next = current.parent;//if we are coming from the right subtree just go back up
            }
            prev = current; //now we hold the old node
            current = next;
        }
    }

    //iterates thru the tree and adds a value count everytime we reach a new node
    public int sizeIterative(BSTNode n) {
        int count=0;
        BSTNode current = n;
        BSTNode prev = null;
        BSTNode next;
        while (current != null) {//continues going untill we react a
            if (prev == current.parent) {
                count++; //if we arrived here from the parent then its a new node and we next visit the left
                if (current.left != null) next = current.left;
                else if (current.right != null) next = current.right;
                else next = current.parent;//if the two children are null we go to the parent
            } else if (prev == current.left) { //if we are just coming from the left subtree
                if (current.right != null) next = current.right;//also if the right node has a value
                else next = current.parent;//if the rigth node is null go up back to parent
            } else {
                next = current.parent;//if we are coming from the right subtree just go back up
            }
            prev = current; //now we hold the old node
            current = next; //set the node that we want to go to as the new current node
        }
        return count;
    }

    public void add(String s) {//should work is getting called
        BSTNode n = new BSTNode(s);
        if (root == null) {
            root=n;
            //size++;
            return;
        }
        BSTNode prev = null;
        BSTNode temp = root;
        while (temp != null ) {
            prev = temp;
            if (n.playerRank() < temp.playerRank()) {//if the data is smaller than the node we are at
                temp = temp.left; //we go to the left of the node
            } else if (n.playerRank() > temp.playerRank())
                temp = temp.right;//else the temp node gets the int to the right bc data we adding is bigger then temps
        }
        //finally once we reach a point where we cannot go any further, the prev node
        if (prev.playerRank() > n.playerRank()) { //we finally put the node to the right of it
            prev.left = n;
        } else { //If the previous nodes data is smaller then we go to the right
            prev.right = n;
        }
        n.parent=prev;
    }

    public String find(int find) {
        BSTNode node = root;
        while (node != null) {

            if (find < node.playerRank()) {
                node = node.left;
            } else if (find > node.playerRank()) {
                node = node.right;
            } else if (find == node.playerRank()) {
                return node.giveName();
            }
        }
        return ("player with rating " + find + " was NOT found");

    }

    public void rank20() {
        BSTNode current = root;
        BSTNode prev = null;
        BSTNode next;
        int r = 0;
        String[] rank = new String[21];
        while (current != null) {//continues going untill we react a
            if (prev == current.parent) {
                if (current.playerRank() <= 20)
                    r = current.playerRank();
                rank[r] = current.giveName();
                if (current.left != null) next = current.left;
                else if (current.right != null) next = current.right;
                else next = current.parent;//if the two children are null we go to the parent
            } else if (prev == current.left) { //if we are just coming from the left subtree
                if (current.right != null) next = current.right;//also if the right node has a value
                else next = current.parent;//if the rigth node is null go up back to parent
            } else {
                next = current.parent;//if we are coming from the right subtree just go back up
            }
            prev = current; //now we hold the old node
            current = next; //set the node that we want to go to as the new current node
        }
        for (int s = 1; s < rank.length; s++) {
            System.out.println(rank[s]);
        }
    }

    public void randomTeam()throws IOException {
        String[] team = new String[10];
        int probability=0;
        int bestPlayers=0;

        //creating an array of random numbers that will be translated to player names
        int[] arr= new int[10];
        for(int i=0; i<arr.length; i++){
            arr[i]= (int) (Math.random()*100);
        }

        //populating a new string array for finding our random team
        for(int j=0; j<arr.length;j++){
            int player=arr[j];
            String p=find(player);
            team[j]=p;
            if(arr[j]<=15){//if team has a player that is within the top 10
                bestPlayers++;
            }
        }
        //print the new team

        for( int y=0; y<arr.length;y++){//this is the rank value of each player
            probability=probability+arr[y];
        }

        //how will players contribute to good team and season?
        teamStats squad = new teamStats(team, probability, bestPlayers);
        squad.seasonTotals();



    }


}