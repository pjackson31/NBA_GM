import java.io.IOException;

public class Main {

    public static void main(String[] args) throws java.io.IOException {
        // Add the players into a java literate file!
        String fileContents;
        String[] players;


        System.out.println("Loading in players 100");
        fileContents = new String(java.nio.file.Files.readAllBytes
                (java.nio.file.Paths.get("src/NBAplayerScoring.txt")));
        players = fileContents.split("\\r?\\n");

        //Alternate data structure where we add the players in a BST
        System.out.println("Successfully put " +
                BstNBA(players, 1) + " players in tree."); //creates the table


    }


    static int BstNBA(String[] nba, int whichHash)throws IOException {
        BST tree=new BST();

        //populating the tree
        for (String guy: nba){
            tree.add(guy);
        }


        //lets rank the players in the table
        System.out.println("Lets see who the top 20 players in the NBA are (1-20)");
        tree.rank20();

        //lets generate a random team of ten players

        tree.randomTeam();

        //Besides the players in the NBA who's the Best Basketball Player Ever?
        System.out.println("Luckily, if you were able to draft "+ tree.find(0)+"then your team will automatically " +
                "win the NBA Championship");

        //how many players were put in the tree
        return tree.sizeIterative(tree.root);
    }
}