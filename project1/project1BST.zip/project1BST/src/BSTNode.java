import java.util.Scanner;

public class BSTNode {
    public String value;
    public BSTNode left,right;
    public BSTNode parent;
    public int rankOverall;
    public String name;

    public BSTNode(String val) {
        value = val;
        left = null;
        right = null;
    }
    public int playerRank(){
        Scanner in = new Scanner(value).useDelimiter("[^0-9]+");
        rankOverall = in.nextInt();
        return rankOverall;
    }

    public String giveName(){
        name = value.replaceAll("[^a-zA-Z]", " ");
        return name;
    }
}
